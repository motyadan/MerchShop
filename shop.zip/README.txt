MerchantUA — Flask demo project prepared to meet the requested criteria.

How to run (Windows):
  python -m venv .venv
  .venv\Scripts\activate
  pip install -r requirements.txt
  python app.py

Notes:
- Усі описи українською.
- Немає зовнішніх навігаційних посилань на інші сайти у меню/контенті.
- Платёжна логіка описана, але не містить зовнішніх редиректів — менеджер інформує клієнта про способи оплати.
- Адмін-форма блокує заборонені категорії.
- Перед публікацією змініть контактний email/телефон на реальні.
